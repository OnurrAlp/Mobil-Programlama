package com.example.odev2; // Kendi paket isminle değiştir

import android.os.Bundle;
import android.view.View;       // Lambda hatası için gerekli
import android.widget.Button;   // 'Cannot resolve symbol Button' hatasını çözer
import android.widget.TextView; // 'Cannot resolve symbol TextView' hatasını çözer
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        // 1. Tanımlamalar
        TextView txtMesaj = findViewById(R.id.txtMesaj);
        Button btnGeri = findViewById(R.id.btnGeri);

        // 2. Veriyi Al ve Yazdır
        // 'setText' hatası, txtMesaj'ın TextView olarak tanımlanmamasından kaynaklanır
        String gelenMesaj = getIntent().getStringExtra("mesaj");
        if (gelenMesaj != null) {
            txtMesaj.setText(gelenMesaj);
        }

        // 3. Tıklama Olayı
        // Eğer lambda (v -> ...) hata verirse, aşağıdaki klasik yöntemi kullan:
        btnGeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Sayfayı kapatır ve ana sayfaya döner
            }
        });
    }
}