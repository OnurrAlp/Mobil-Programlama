package com.example.odev4;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    ImageView rastgeleImageView;
    Button btnSehirler;

    // 9 resimlik dizi
    int[] resimDizisi = {
            R.drawable.resim1, R.drawable.resim2, R.drawable.resim3,
            R.drawable.resim4, R.drawable.resim5, R.drawable.resim6,
            R.drawable.resim7, R.drawable.resim8, R.drawable.resim9
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rastgeleImageView = findViewById(R.id.rastgeleImageView);
        btnSehirler = findViewById(R.id.btnSehirler);

        // Rastgele resim seçme ve ekranda (istediğin kodla) gösterme
        Random random = new Random();
        int rastgeleIndex = random.nextInt(resimDizisi.length);
        
        // Ekranda yazan kod tarzı:
        rastgeleImageView.setImageResource(resimDizisi[rastgeleIndex]);

        // Butona tıklandığında Diyalog Penceresi açma
        btnSehirler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                diyalogGoster();
            }
        });
    }

    private void diyalogGoster() {
        String[] sehirler = {"İstanbul", "Ankara", "İzmir"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Şehir Seçiniz");
        builder.setItems(sehirler, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent intent;
                switch (which) {
                    case 0:
                        intent = new Intent(MainActivity.this, IstanbulActivity.class);
                        startActivity(intent);
                        break;
                    case 1:
                        intent = new Intent(MainActivity.this, AnkaraActivity.class);
                        startActivity(intent);
                        break;
                    case 2:
                        intent = new Intent(MainActivity.this, IzmirActivity.class);
                        startActivity(intent);
                        break;
                }
            }
        });
        builder.show();
    }
}