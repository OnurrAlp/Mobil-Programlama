package com.example.odev4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class IstanbulActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_istanbul);

        ImageView image1 = findViewById(R.id.image1);
        ImageView image2 = findViewById(R.id.image2);
        ImageView image3 = findViewById(R.id.image3);
        Button btnGeri = findViewById(R.id.btnGeri);

        // İstanbul için resim7, resim8, resim9 kullanıyoruz
        image1.setImageResource(R.drawable.resim7);
        image2.setImageResource(R.drawable.resim8);
        image3.setImageResource(R.drawable.resim9);

        btnGeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Mevcut aktiviteyi kapatır ve bir önceki ekrana (Main) döner
            }
        });
    }
}