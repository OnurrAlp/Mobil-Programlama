package com.example.odev4;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class AnkaraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ankara);

        ImageView image1 = findViewById(R.id.image1);
        ImageView image2 = findViewById(R.id.image2);
        ImageView image3 = findViewById(R.id.image3);
        Button btnGeri = findViewById(R.id.btnGeri);

        // Ankara için resim1, resim2, resim3 kullanıyoruz
        image1.setImageResource(R.drawable.resim1);
        image2.setImageResource(R.drawable.resim2);
        image3.setImageResource(R.drawable.resim3);

        btnGeri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Mevcut aktiviteyi kapatır ve bir önceki ekrana (Main) döner
            }
        });
    }
}