package com.example.hesapmakinesi;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    double firstNum = 0;
    String operator = "";
    boolean isNewOperation = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        TextView Screen = findViewById(R.id.Screen);

        Button btn0 = findViewById(R.id.Button0);
        Button btn1 = findViewById(R.id.Button1);
        Button btn2 = findViewById(R.id.Button2);
        Button btn3 = findViewById(R.id.Button3);
        Button btn4 = findViewById(R.id.Button4);
        Button btn5 = findViewById(R.id.Button5);
        Button btn6 = findViewById(R.id.Button6);
        Button btn7 = findViewById(R.id.Button7);
        Button btn8 = findViewById(R.id.Button8);
        Button btn9 = findViewById(R.id.Button9);

        Button btnToplama = findViewById(R.id.ButtonPlus);
        Button btnCıkarma = findViewById(R.id.ButtonExtraction);
        Button btnCarpma = findViewById(R.id.ButtonMultipy);
        Button btnBölme = findViewById(R.id.ButtonDivide);
        Button btnMod = findViewById(R.id.ButtonMod);
        Button btnKesir = findViewById(R.id.ButtonFraction);
        Button btnÜs = findViewById(R.id.ButtonPover);
        Button btnKök = findViewById(R.id.ButtonSquareRoot);
        Button btnEqual = findViewById(R.id.ButtonEqual);
        Button btnClear = findViewById(R.id.ButtonClear);

        View.OnClickListener numberListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                if (isNewOperation) {
                    Screen.setText(b.getText().toString());
                    isNewOperation = false;
                } else {
                    Screen.append(b.getText().toString());
                }
            }
        };

        Button[] numbers = {btn0, btn1, btn2, btn3, btn4, btn5, btn6, btn7, btn8, btn9};
        for (Button btn : numbers) {
            if (btn != null) btn.setOnClickListener(numberListener);
        }

        View.OnClickListener opListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Button b = (Button) v;
                firstNum = Double.parseDouble(Screen.getText().toString());
                operator = b.getText().toString();
                isNewOperation = true;
            }
        };

        btnToplama.setOnClickListener(opListener);
        btnCıkarma.setOnClickListener(opListener);
        btnCarpma.setOnClickListener(opListener);
        btnBölme.setOnClickListener(opListener);
        btnMod.setOnClickListener(opListener);
        btnÜs.setOnClickListener(opListener);

        btnKök.setOnClickListener(v -> {
            double val = Double.parseDouble(Screen.getText().toString());
            Screen.setText(String.valueOf(Math.sqrt(val)));
            isNewOperation = true;
        });

        btnKesir.setOnClickListener(v -> {
            double val = Double.parseDouble(Screen.getText().toString());
            Screen.setText(String.valueOf(1 / val));
            isNewOperation = true;
        });

        btnEqual.setOnClickListener(v -> {
            double secondNum = Double.parseDouble(Screen.getText().toString());
            double result = 0;
            if (operator.equals("+")) result = firstNum + secondNum;
            else if (operator.equals("-")) result = firstNum - secondNum;
            else if (operator.equals("*") || operator.equals("x") || operator.equals("X")) result = firstNum * secondNum;
            else if (operator.equals("/")) {
                if (secondNum != 0) result = firstNum / secondNum;
            }
            else if (operator.equals("%")) result = firstNum % secondNum;
            else if (operator.equals("^") || operator.contains("X")) result = Math.pow(firstNum, secondNum);

            Screen.setText(String.valueOf(result));
            isNewOperation = true;
        });

        btnClear.setOnClickListener(v -> {
            Screen.setText("0");
            firstNum = 0;
            operator = "";
            isNewOperation = true;
        });
    }
}