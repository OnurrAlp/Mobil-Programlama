package com.example.odev5;

import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.ToggleButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Wifi extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wifi);

        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        ToggleButton toggleWifi = findViewById(R.id.toggleWifi);
        Button btnBackWifi = findViewById(R.id.btnBackWifi);

        // Başlangıç durumunu ayarla
        if (wifiManager != null) {
            toggleWifi.setChecked(wifiManager.isWifiEnabled());
        }

        toggleWifi.setOnClickListener(v -> {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10 ve üzeri: Panel açarak tek tuşla işlem yapılması sağlanır
                Intent intent = new Intent(Settings.Panel.ACTION_WIFI);
                startActivityForResult(intent, 101);
                Toast.makeText(this, "Lütfen Wifi durumunu panelden değiştirin", Toast.LENGTH_SHORT).show();
            } else {
                // Eski sürümler için doğrudan kontrol
                if (wifiManager != null) {
                    wifiManager.setWifiEnabled(toggleWifi.isChecked());
                }
            }
        });

        btnBackWifi.setOnClickListener(v -> finish());
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Ayarlardan dönüldüğünde butonu güncelle
        WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
        ToggleButton toggleWifi = findViewById(R.id.toggleWifi);
        if (wifiManager != null && toggleWifi != null) {
            toggleWifi.setChecked(wifiManager.isWifiEnabled());
        }
    }
}